
from bottle import default_app, route, template, post

@route('/')
def main():
    return template("form.html")

@post('/convert')
def convert():
    return template("result.html")


application = default_app()

