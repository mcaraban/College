
from bottle import default_app, route, template, post

import sqlite3
QuizDB = sqlite3.connect("./Quiz.db")
QuizC=QuizDB.cursor()

@route('/Quiz')
def main():
    return template("Quizmenu.html")

@route('/Quiz/Africa')
def AfricaQuiz():
    return template("AfricaQuiz.html",c = QuizC, db = QuizDB)

@post('/Quiz/Africa/Result')
def AfricaQuizResult():
    return template("AfricaQuizResult.html", c = QuizC, db = QuizDB)

@route('/Quiz/Asia')
def AsiaQuiz():
    return template("AsiaQuiz.html", c = QuizC, db = QuizDB)

@post('/Quiz/Asia/Result')
def AsiaQuizResult():
    return template("AsiaQuizResult.html", c = QuizC, db = QuizDB)

@route('/Quiz/Europe')
def EuropeQuiz():
    return template("EuropeQuiz.html", c = QuizC, db = QuizDB)

@post('/Quiz/Europe/Result')
def EuropeQuizResult():
    return template("EuropeQuizResult.html", c = QuizC, db = QuizDB)

@route('/Quiz/North&CentralAmerica')
def NorthCentralAmericaQuiz():
    return template("North&CentralQuiz.html", c = QuizC, db = QuizDB)

@post('/Quiz/North&CentralAmerica/Result')
def NorthCentralAmericaQuizResult():
    return template("North&CentralQuizResult.html", c = QuizC, db = QuizDB)

@route('/Quiz/Oceania')
def OceaniaQuiz():
    return template("OceaniaQuiz.html", c = QuizC, db = QuizDB)

@post('/Quiz/Oceania/Result')
def OceaniaQuizResult():
    return template("OceaniaQuizResult.html", c = QuizC, db = QuizDB)

@route('/Quiz/SouthAmerica')
def SouthAmericaQuiz():
    return template("SouthAmericaQuiz.html", c = QuizC, db = QuizDB)

@post('/Quiz/SouthAmerica/Result')
def SouthAmericaQuizResult():
    return template("SouthAmericaQuizResult.html", c = QuizC, db = QuizDB)



application = default_app()


@route('/')
def main():
    return template("form.html")

@post('/convert')
def convert():
    return template("result.html")


